package com.ecnu.stldemo.elements.abstracts;

public abstract class Expression {
}
