package com.ecnu.stldemo.elements.element.predicates_Type;


import com.ecnu.stldemo.elements.abstracts.Predicates;

public class LEPredicate extends Predicates {
    /**
     * "<="
     * @param sigName
     * @param num
     */
    public LEPredicate(String sigName, double num) {
        super(sigName, num);
    }
}
