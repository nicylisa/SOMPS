package com.ecnu.stldemo.elements.element.expressionone;

import com.ecnu.stldemo.elements.abstracts.Expression;
import com.ecnu.stldemo.elements.abstracts.ExpressionOne;

public class NotExpression extends ExpressionOne {
    public NotExpression(Expression expr) {
        super(expr);
    }
}
