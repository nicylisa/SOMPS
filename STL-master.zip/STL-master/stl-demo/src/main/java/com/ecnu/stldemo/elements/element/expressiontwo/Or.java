package com.ecnu.stldemo.elements.element.expressiontwo;

import com.ecnu.stldemo.elements.abstracts.Expression;
import com.ecnu.stldemo.elements.abstracts.ExpressionTwo;

public class Or extends ExpressionTwo {
    public Or(Expression left, Expression right){
        super(left,right);
    }
}
