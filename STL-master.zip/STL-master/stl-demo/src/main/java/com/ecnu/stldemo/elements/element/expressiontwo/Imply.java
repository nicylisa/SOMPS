package com.ecnu.stldemo.elements.element.expressiontwo;

import com.ecnu.stldemo.elements.abstracts.Expression;
import com.ecnu.stldemo.elements.abstracts.ExpressionTwo;

public class Imply extends ExpressionTwo {
    public Imply(Expression left, Expression right){
        super(left,right);
    }
}
