package com.ecnu.stldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StlDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StlDemoApplication.class, args);
	}

}
