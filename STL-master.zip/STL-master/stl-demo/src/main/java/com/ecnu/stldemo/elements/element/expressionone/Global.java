package com.ecnu.stldemo.elements.element.expressionone;


import com.ecnu.stldemo.elements.abstracts.Expression;
import com.ecnu.stldemo.elements.abstracts.IntervalOne;

public class Global extends IntervalOne {

    public Global(Expression expression, double start, double end) {
        super(expression, start, end);
    }
}
