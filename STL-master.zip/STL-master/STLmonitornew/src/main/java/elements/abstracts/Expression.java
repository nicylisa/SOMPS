package elements.abstracts;

public abstract class Expression {
}
