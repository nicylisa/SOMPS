package elements.element.expressionone;


import elements.abstracts.Expression;
import elements.abstracts.IntervalOne;

public class Eventually extends IntervalOne {

    public Eventually(Expression expression, double start, double end) {
        super(expression, start, end);
    }

}
