package elements.element.predicates_Type;

import elements.abstracts.Predicates;

public class LTPredicate extends Predicates {
    /**
     * "<"
     * @param sigName
     * @param num
     */
    public LTPredicate(String sigName, double num) {
        super(sigName, num);
    }
}
