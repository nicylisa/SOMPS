package elements.element.expressiontwo;
import elements.abstracts.Expression;
import elements.abstracts.ExpressionTwo;

public class Or extends ExpressionTwo {
    public Or(Expression left,Expression right){
        super(left,right);
    }
}
