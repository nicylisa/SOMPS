package elements.element.expressionone;


import elements.abstracts.Expression;
import elements.abstracts.ExpressionOne;

public class NotExpression extends ExpressionOne {
    public NotExpression(Expression expr) {
        super(expr);
    }
}
