package elements.element.expressiontwo;
import elements.abstracts.Expression;
import elements.abstracts.ExpressionTwo;

public class And extends ExpressionTwo {
    public And(Expression left, Expression right) {
        super(left, right);
    }
}
