package elements.element.expressiontwo;
import elements.abstracts.Expression;
import elements.abstracts.ExpressionTwo;

public class Imply extends ExpressionTwo {
    public Imply(Expression left,Expression right){
        super(left,right);
    }
}
