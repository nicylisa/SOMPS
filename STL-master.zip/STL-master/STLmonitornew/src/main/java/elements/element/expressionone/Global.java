package elements.element.expressionone;

import elements.abstracts.Expression;
import elements.abstracts.IntervalOne;

public class Global extends IntervalOne {

    public Global(Expression expression, double start, double end) {
        super(expression, start, end);
    }
}
