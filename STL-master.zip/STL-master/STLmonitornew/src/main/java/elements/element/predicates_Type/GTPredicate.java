package elements.element.predicates_Type;

import elements.abstracts.Predicates;

public class GTPredicate extends Predicates {
    /**
     * ">"
     * @param sigName
     * @param num
     */
    public GTPredicate(String sigName, double num) {
        super(sigName, num);
    }
}
